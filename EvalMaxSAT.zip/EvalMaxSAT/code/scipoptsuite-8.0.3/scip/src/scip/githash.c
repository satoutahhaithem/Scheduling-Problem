#define SCIP_GITHASH "62fab8a2e3"
